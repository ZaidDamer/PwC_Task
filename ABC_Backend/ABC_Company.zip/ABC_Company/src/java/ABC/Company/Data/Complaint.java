/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ABC.Company.Data;

/**
 *
 * @author ZaidDamer
 */
public class Complaint {

    private int idComplaint;
    private String title;
    private String productName;
    private String dateofPurchace;
    private String productBoughtAs;
    private String customerID;
    private String contactMethod;
    private String complaintStatus;
    private String status;
    private String description;

    public int getIdComplaint() {
        return idComplaint;
    }

    public void setIdComplaint(int idComplaint) {
        this.idComplaint = idComplaint;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDateofPurchace() {
        return dateofPurchace;
    }

    public void setDateofPurchace(String dateofPurchace) {
        this.dateofPurchace = dateofPurchace;
    }

    public String getProductBoughtAs() {
        return productBoughtAs;
    }

    public void setProductBoughtAs(String productBoughtAs) {
        this.productBoughtAs = productBoughtAs;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getContactMethod() {
        return contactMethod;
    }

    public void setContactMethod(String contactMethod) {
        this.contactMethod = contactMethod;
    }

    public String getComplaintStatus() {
        return complaintStatus;
    }

    public void setComplaintStatus(String complaintStatus) {
        this.complaintStatus = complaintStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    
}
