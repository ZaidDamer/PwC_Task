/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ABC.Company.Service;

/**
 *
 * @author ZaidDamer
 */
import ABC.Company.Data.Complaint;
import ABC.Company.Data.Customers;
import ABC.Company.Data.Employees;
import ABC.Company.Data.StatusC;
import ABC.Company.Database.DataBaseFunctions;
import java.io.IOException;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;

@ApplicationPath("/resources")
@Path("/ABCCompany")
public class Services extends Application implements ContainerResponseFilter {

    @Override
    public void filter(final ContainerRequestContext requestContext,
            final ContainerResponseContext cres) throws IOException {
        cres.getHeaders().add("Access-Control-Allow-Origin", "*");
        cres.getHeaders().add("Access-Control-Allow-Headers", "origin, content-type, accept, authorization");
        cres.getHeaders().add("Access-Control-Allow-Credentials", "true");
        cres.getHeaders().add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD");
        cres.getHeaders().add("Access-Control-Max-Age", "1209600");
    }

    @POST
    @Consumes("application/json")
    @Path("/AddUser")
    public StatusC createCustomer(Customers c) {
        Customers customers = new Customers();
        DataBaseFunctions baseFunctions = new DataBaseFunctions();

        byte[] bytePassword = c.getPassword().getBytes();
        byte[] b64encodedPassword = Base64.getEncoder().encode(bytePassword);
        String encodedPasswordstring = new String(b64encodedPassword);
        
        customers.setFirstName(c.getFirstName());
        customers.setLastName(c.getLastName());
        customers.setDateOfBirth(c.getDateOfBirth());
        customers.setEmail(c.getEmail());
        customers.setMobileNumber(c.getMobileNumber());
        customers.setPassword(encodedPasswordstring);
        customers.setGender(c.getGender());
        customers.setMaritalStatus(c.getMaritalStatus());
        customers.setStatus("Active");

        StatusC createCustomerResponse = baseFunctions.createCustomer(customers);
        return createCustomerResponse;
    }

    @POST
    @Path("/AddEmployee")
    public StatusC createEmployee(Employees e) {
        Employees employees = new Employees();
        DataBaseFunctions baseFunctions = new DataBaseFunctions();

        byte[] bytePassword = e.getPassword().getBytes();
        byte[] b64encodedPassword = Base64.getEncoder().encode(bytePassword);
        String encodedPasswordstring = new String(b64encodedPassword);
           

        employees.setFirstName(e.getFirstName());
        employees.setLastName(e.getLastName());
        employees.setDepartment(e.getDepartment());
        employees.setDateOfBirth(e.getDateOfBirth());
        employees.setEmail(e.getEmail());
        employees.setMobileNumber(e.getMobileNumber());
        employees.setPassword(encodedPasswordstring);
        employees.setGender(e.getGender());
        employees.setMaritalStatus(e.getMaritalStatus());
        employees.setStatus("Active");

        StatusC createEmployeeResponse = baseFunctions.createEmployee(employees);
        return createEmployeeResponse;
    }

    @POST
    @Path("/CreateComplaint")
    public StatusC createComplaint(Complaint c) {
        Complaint complaint = new Complaint();
        DataBaseFunctions baseFunctions = new DataBaseFunctions();

        complaint.setTitle(c.getTitle());
        complaint.setDateofPurchace(c.getDateofPurchace());
        complaint.setProductName(c.getProductName());
        complaint.setProductBoughtAs(c.getProductBoughtAs());
        complaint.setContactMethod(c.getContactMethod());
        complaint.setDescription(c.getDescription());
        complaint.setCustomerID(c.getCustomerID());
        complaint.setComplaintStatus("Pending");
        complaint.setStatus("Active");

        StatusC createComplaintResponse = baseFunctions.createComplaint(complaint);
        return createComplaintResponse;
    }

    @GET
    @Path("/ComplaintsByUserID/{id}")
    public List<Complaint> GetComplaintsByUserID(@PathParam("id") String id) {
        DataBaseFunctions baseFunctions = new DataBaseFunctions();
        List<Complaint> UserComplaints = new ArrayList<>();
        UserComplaints = baseFunctions.GetUserComplaints(id);
        return UserComplaints;
    }

    @GET
    @Path("/AllComplaints")
    public List<Complaint> GetAllComplaints() {
        DataBaseFunctions baseFunctions = new DataBaseFunctions();
        List<Complaint> AllComplaints = new ArrayList<>();
        AllComplaints = baseFunctions.GetAllComplaints();
        return AllComplaints;
    }

    @POST
    @Path("/Login")
    public Customers CustomerLogin(Customers credentials) {

        DataBaseFunctions baseFunctios = new DataBaseFunctions();

        Customers Messageresponse = baseFunctios.CustomerLogin(credentials);
        return Messageresponse;
    }

    @POST
    @Path("/EmployeeLogin")
    public Employees EmployeeLogin(Employees credentials) {

        DataBaseFunctions baseFunctios = new DataBaseFunctions();

        Employees Messageresponse = baseFunctios.EmployeeLogin(credentials);
        return Messageresponse;
    }

    @POST
    @Path("/UpdateComplaint")
    public Complaint UpdateComplaint(Complaint complaint) {

        DataBaseFunctions baseFunctios = new DataBaseFunctions();

        Complaint Messageresponse = baseFunctios.UpdateComplaint(complaint);
        return Messageresponse;
    }

}
