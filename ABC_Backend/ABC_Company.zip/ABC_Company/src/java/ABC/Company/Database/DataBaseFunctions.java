/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ABC.Company.Database;

import ABC.Company.Data.Complaint;
import ABC.Company.Data.Customers;
import ABC.Company.Data.Employees;
import ABC.Company.Data.StatusC;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 *
 * @author ZaidDamer
 */
public class DataBaseFunctions {

    private Connection dbcon;

    public DataBaseFunctions() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.dbcon = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql?autoReconnect=true&useSSL=false", "root", "P@ssw0rd");
            System.out.println("Connection success");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Connection refuse" + e);
        }
    }

    //Register Customer
    public StatusC createCustomer(Customers c) {
        StatusC createCustomerResponse = new StatusC();
        try {
            String query = "INSERT INTO `abc_company`.`customers` (`firstName`, `lastName`, `dateOfBirth`, `mobileNumber`, `email`, `password`, `gender`, `maritalStatus`, `status`) VALUES "
                    + "('" + c.getFirstName() + "','" + c.getLastName() + "','" + c.getDateOfBirth() + "','" + c.getMobileNumber() + "','" + c.getEmail() + "','" + c.getPassword() + "','" + c.getGender() + "','" + c.getMaritalStatus() + "','" + c.getStatus() + "');";

            PreparedStatement preparedStmt = dbcon.prepareStatement(query);
            preparedStmt.execute();
            dbcon.close();
        } catch (SQLException ex) {
            createCustomerResponse.setStatus(ex + "Failed Adding Customer");
            System.out.println(ex);
            return createCustomerResponse;
        }
        createCustomerResponse.setStatus("Successfully");
        return createCustomerResponse;
    }

    //Register Employee
    public StatusC createEmployee(Employees e) {
        StatusC createEmployeeResponse = new StatusC();
        try {
            String query = "INSERT INTO `abc_company`.`employees` (`firstName`, `lastName`, `department`, `dateOfBirth`, `mobileNumber`, `email`, `password`, `gender`, `maritalStatus`, `status`) VALUES "
                    + "('" + e.getFirstName() + "','" + e.getLastName() + "','" + e.getDepartment() + "','" + e.getDateOfBirth() + "','" + e.getMobileNumber() + "','" + e.getEmail() + "','" + e.getPassword() + "','" + e.getGender() + "','" + e.getMaritalStatus() + "','" + e.getStatus() + "');";

            PreparedStatement preparedStmt = dbcon.prepareStatement(query);
            preparedStmt.execute();
            dbcon.close();
        } catch (SQLException ex) {
            createEmployeeResponse.setStatus(ex + "Failed Adding Customer");
            System.out.println(ex);
            return createEmployeeResponse;
        }
        createEmployeeResponse.setStatus("Successfully");
        return createEmployeeResponse;
    }

    //Create New Complaint
    public StatusC createComplaint(Complaint c) {
        StatusC createComplaintResponse = new StatusC();
        try {
            String query = "INSERT INTO `abc_company`.`complaint` (`Title`, `ProductName`, `DateofPurchace`, `ProductBoughtAs`, `CustomerID`, `ContactMethod`, `ComplaintStatus`, `Status`, `Description`) VALUES "
                    + "('" + c.getTitle() + "','" + c.getProductName() + "','" + c.getDateofPurchace() + "','" + c.getProductBoughtAs() + "','" + c.getCustomerID()
                    + "','" + c.getContactMethod() + "','" + c.getComplaintStatus() + "','" + c.getStatus() + "','" + c.getDescription() + "');";

            PreparedStatement preparedStmt = dbcon.prepareStatement(query);
            preparedStmt.execute();
            dbcon.close();
        } catch (SQLException ex) {
            createComplaintResponse.setStatus(ex + "Failed Adding Customer");
            System.out.println(ex);
            return createComplaintResponse;
        }
        createComplaintResponse.setStatus("Successfully");
        return createComplaintResponse;
    }

    //Get User's Complaints
    public List<Complaint> GetUserComplaints(String customerID) {
        List<Complaint> UserComplaints = new ArrayList<>();
        try {
            String query = "SELECT * FROM abc_company.complaint where abc_company.complaint.CustomerID = " + customerID + ";";

            Statement Stmt = dbcon.createStatement();
            ResultSet rs = Stmt.executeQuery(query);

            while (rs.next()) {
                Complaint UC = new Complaint();
                UC.setIdComplaint(rs.getInt("idComplaint"));
                UC.setTitle(rs.getString("Title"));
                UC.setComplaintStatus(rs.getString("ComplaintStatus"));
                UC.setDescription(rs.getString("Description"));
                UserComplaints.add(UC);
            }
            dbcon.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return UserComplaints;
    }

    //Get All Complaints
    public List<Complaint> GetAllComplaints() {
        List<Complaint> AllComplaints = new ArrayList<>();
        try {
            String query = "SELECT * FROM abc_company.complaint;";

            Statement Stmt = dbcon.createStatement();
            ResultSet rs = Stmt.executeQuery(query);

            while (rs.next()) {
                Complaint AC = new Complaint();
                AC.setIdComplaint(rs.getInt("idComplaint"));
                AC.setTitle(rs.getString("Title"));
                AC.setComplaintStatus(rs.getString("ComplaintStatus"));
                AC.setDescription(rs.getString("Description"));
                AllComplaints.add(AC);
            }
            dbcon.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return AllComplaints;
    }

    //Customer Login
    public Customers CustomerLogin(Customers c) {
        Customers c1 = new Customers();
        try {
        byte[] bytePassword = c.getPassword().getBytes();
        byte[] b64encodedPassword = Base64.getEncoder().encode(bytePassword);
        String encodedPasswordstring = new String(b64encodedPassword);
        
            String query = "SELECT * FROM abc_company.customers where email = '" + c.getEmail() + "' and password = '" + encodedPasswordstring + "'  ;";

            Statement Stmt = dbcon.createStatement();
            ResultSet rs = Stmt.executeQuery(query);

            while (rs.next()) {
                c1.setCustomerID(rs.getInt("CustomerID"));
            }

            dbcon.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return c1;
    }

    //Employee Login
    public Employees EmployeeLogin(Employees c) {
        Employees e1 = new Employees();
        try {
           
        byte[] bytePassword = c.getPassword().getBytes();
        byte[] b64encodedPassword = Base64.getEncoder().encode(bytePassword);
        String encodedPasswordstring = new String(b64encodedPassword);
            
            String query = "SELECT * FROM abc_company.employees where email = '" + c.getEmail() + "' and password = '" + encodedPasswordstring + "'  ;";

            Statement Stmt = dbcon.createStatement();
            ResultSet rs = Stmt.executeQuery(query);

            while (rs.next()) {
                e1.setEmployeeID(rs.getInt("EmployeeID"));
            }

            dbcon.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return e1;
    }

    //Update Complaint Status
    public Complaint UpdateComplaint(Complaint complaint) {
        Complaint c1 = new Complaint();
        try {
            String query = "UPDATE abc_company.complaint SET `ComplaintStatus` = '" + complaint.getComplaintStatus() + "' WHERE (`idComplaint` = '" + complaint.getIdComplaint() + "');";

            PreparedStatement Stmt = dbcon.prepareStatement(query);
            Stmt.execute();
            dbcon.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return c1;
    }
}
