var custId;
function Logout() {
  window.location.replace("./CustomerLogin.html");
}

function SubmitComplaint() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      document.getElementById("ComplaintTitle").value = "";
      document.getElementById("ProductNameList").value = "";
      document.getElementById("DOP").value = "";
      document.getElementById("Description").value = "";

      window.location.replace("./HomeScreen.html?" + custId);
    }
  };
  xhttp.open(
    "POST",
    "http://localhost:8080/ABC_Company/resources/ABCCompany/CreateComplaint",
    true
  );
  xhttp.setRequestHeader("Content-Type", "application/json");

  var contactCheckboxes = document.getElementsByName("Contact");
  var contactCheckbox = "";
  for (var i = 0, length = contactCheckboxes.length; i < length; i++) {
    if (contactCheckboxes[i].checked) {
      contactCheckbox = contactCheckbox + ", " + contactCheckboxes[i].value;
    }
  }
  contactCheckbox = contactCheckbox.substring(2);

  var productBoughtAsRadios = document.getElementsByName("productBoughtAs");
  var productBoughtAsRadiosradio = "";
  for (var j = 0, length2 = productBoughtAsRadios.length; j < length2; j++) {
    if (productBoughtAsRadios[j].checked) {
      productBoughtAsRadiosradio = productBoughtAsRadios[j].value;
      break;
    }
  }

  custId = window.location.href;
  custId = custId.substring(custId.length - 1);

  var params =
    '{ "title":"' +
    document.getElementById("ComplaintTitle").value +
    '","productName":"' +
    document.getElementById("ProductNameList").value +
    '","dateofPurchace":"' +
    document.getElementById("DOP").value +
    '","productBoughtAs":"' +
    productBoughtAsRadiosradio +
    '","contactMethod":"' +
    contactCheckbox +
    '","description":"' +
    document.getElementById("Description").value +
    '","customerID":"' +
    custId +
    '"}';

  xhttp.send(params);
}
