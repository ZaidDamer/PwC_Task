function Logout() {
  window.location.replace("./AdminLogin.html");
}

function GetAllComplaints() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      console.log(this.responseText);
      const myJson = JSON.parse(this.responseText);
      updateTable(myJson);
    }
  };
  xhttp.open(
    "GET",
    "http://localhost:8080/ABC_Company/resources/ABCCompany/AllComplaints",
    true
  );
  xhttp.send();
}

function updateTable(jsonData) {
  var tableHTML =
    "<tr><th>Complaint ID</th><th>Complaint Title</th><th>Complaint Description</th><th>Complaint Status</th></tr>";

  for (var eachItem in jsonData) {
    tableHTML += '<tr onclick="EditComplaintStatus(this)">';
    var dataObj = jsonData[eachItem];
    tableHTML +=
      "<td>" +
      dataObj["idComplaint"] +
      "</td>" +
      "<td>" +
      dataObj["title"] +
      "</td>" +
      "<td>" +
      dataObj["description"] +
      "</td>" +
      "<td>" +
      dataObj["complaintStatus"] +
      "</td>";
    tableHTML += "</tr>";
  }
  document.getElementById("ComplaintTable").innerHTML = tableHTML;
}

function EditComplaintStatus(selectedRow) {
  document.getElementById("compID").value = selectedRow.cells[0].innerHTML + "";
  document.getElementById("compTitle").value = selectedRow.cells[1].innerHTML;
  document.getElementById("compStatusList").value =
    selectedRow.cells[3].innerHTML;
}

function EditComplaintStatusService() {
  if (document.getElementById("compID").value != "") {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        alert("Compliant Status Edited");
        document.getElementById("compID").value = "";
        document.getElementById("compTitle").value = "";
        document.getElementById("compStatusList").value = "";
        GetAllComplaints();
      }
    };
    xhttp.open(
      "POST",
      "http://localhost:8080/ABC_Company/resources/ABCCompany/UpdateComplaint",
      true
    );
    xhttp.setRequestHeader("Content-Type", "application/json");

    var params =
      '{ "idComplaint":"' +
      document.getElementById("compID").value +
      '","complaintStatus":"' +
      document.getElementById("compStatusList").value +
      '"}';

    xhttp.send(params);
  } else {
    alert("Please select complaint from the table below");
  }
}
