var custId;

GetUserComplaints();
function funcNewComplaint() {
  window.location.replace("./ComplaintRequest.html?" + custId);
}

function Logout() {
  window.location.replace("./CustomerLogin.html");
}

function GetUserComplaints() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      console.log(this.responseText);
      const myJson = JSON.parse(this.responseText);
      updateTable(myJson);
    }
  };
  custId = window.location.href;
  custId = custId.substring(custId.length - 1);

  xhttp.open(
    "GET",
    "http://localhost:8080/ABC_Company/resources/ABCCompany/ComplaintsByUserID/" +
      custId,
    true
  );
  xhttp.send();
}

function updateTable(jsonData) {
  var tableHTML =
    "<tr><th>Complaint ID</th><th>Complaint Title</th><th>Complaint Description</th><th>Complaint Status</th></tr>";

  for (var eachItem in jsonData) {
    tableHTML += "<tr>";
    var dataObj = jsonData[eachItem];
    tableHTML +=
      "<td>" +
      dataObj["idComplaint"] +
      "</td>" +
      "<td>" +
      dataObj["title"] +
      "</td>" +
      "<td>" +
      dataObj["description"] +
      "</td>" +
      "<td>" +
      dataObj["complaintStatus"] +
      "</td>";
    tableHTML += "</tr>";
  }
  document.getElementById("ComplaintTable").innerHTML = tableHTML;
}
