function CustomerRegister() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      document.getElementById("firstname").value = "";
      document.getElementById("lastname").value = "";
      document.getElementById("DOB").value = "";
      document.getElementById("mobileNumber").value = "";
      document.getElementById("email").value = "";
      document.getElementById("psw").value = "";
      alert("Registration done successfully!");
      window.location.replace("./CustomerLogin.html");
    }
  };
  xhttp.open(
    "POST",
    "http://localhost:8080/ABC_Company/resources/ABCCompany/AddUser",
    true
  );
  xhttp.setRequestHeader("Content-Type", "application/json");

  var genderRadios = document.getElementsByName("gender");
  var genderradio = "";
  for (var i = 0, length = genderRadios.length; i < length; i++) {
    if (genderRadios[i].checked) {
      genderradio = genderRadios[i].value;
      break;
    }
  }

  var maritalRadios = document.getElementsByName("marital");
  var maritalradio = "";
  for (var j = 0, length2 = maritalRadios.length; j < length2; j++) {
    if (maritalRadios[j].checked) {
      maritalradio = maritalRadios[j].value;
      break;
    }
  }

  var params =
    '{ "firstName":"' +
    document.getElementById("firstname").value +
    '","lastName":"' +
    document.getElementById("lastname").value +
    '","dateOfBirth":"' +
    document.getElementById("DOB").value +
    '","mobileNumber":"' +
    document.getElementById("mobileNumber").value +
    '","email":"' +
    document.getElementById("email").value +
    '","password":"' +
    document.getElementById("psw").value +
    '","gender":"' +
    genderradio +
    '","maritalStatus":"' +
    maritalradio +
    '"}';

  xhttp.send(params);
}
