function AdminLogin() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      console.log(this.responseText);
      const res = JSON.parse(this.responseText);
      if (res.employeeID > 0) {
        document.getElementById("uname").value = "";
        document.getElementById("psw").value = "";
        window.location.replace("./AdminPortal.html");
      } else {
        alert("Wrong Username or Password");
      }
    }
  };
  xhttp.open(
    "POST",
    "http://localhost:8080/ABC_Company/resources/ABCCompany/EmployeeLogin",
    true
  );
  xhttp.setRequestHeader("Content-Type", "application/json");

  var params =
    '{ "email":"' +
    document.getElementById("uname").value +
    '","password":"' +
    document.getElementById("psw").value +
    '"}';

  xhttp.send(params);
}
